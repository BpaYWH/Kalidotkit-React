import React from "react";
import { useEffect } from "react";

import "./App.css";


function useCDNScript(url, timeout) {
   useEffect(() => {
      setTimeout(() => {
         const script = document.createElement("script");
         script.src = url;
         script.async = true;
         document.body.appendChild(script);
         return () => {
            document.body.removeChild(script);
         };
      }, timeout);
   }, [url]);
}

function App() {
   useCDNScript("https://unpkg.com/three@0.133.0/build/three.js", 0);
   useCDNScript("https://unpkg.com/three@0.133.0/examples/js/loaders/GLTFLoader.js",1000);
   useCDNScript("https://unpkg.com/@pixiv/three-vrm@0.6.7/lib/three-vrm.js",1000);
   useCDNScript("https://unpkg.com/three@0.133.0/examples/js/controls/OrbitControls.js",1000);

   useCDNScript("https://cdn.jsdelivr.net/npm/@mediapipe/holistic@0.5.1635989137/holistic.js",1000);
   useCDNScript("https://cdn.jsdelivr.net/npm/@mediapipe/drawing_utils/drawing_utils.js",1000);
   useCDNScript("https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js",1000);
   
   useCDNScript("https://cdn.jsdelivr.net/npm/kalidokit@1.1/dist/kalidokit.umd.js",1000);
   
   useCDNScript("/asset/character.js",1000);

   const handleClick = () => {

   }

   return (
      <div className="App">
         <video className="input_video"></video>
         <canvas className="guides"></canvas>
         <button onClick={handleClick}>Yo</button>
      </div>
   );
}

export default App;
